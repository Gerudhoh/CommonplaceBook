This application is a simple webpage with a plant search bar 
The Search button attempts to search the name of a plant.
The Show My Plants button shows the user a list of all the plants they've saved. The results are unique for each user.
Just run the webpage with flask (flask run --host=0.0.0.0 --port=16930), go to localhost (http://0.0.0.0:16930/), and try to search a plant! Then try to save it to find out more about it! :)

NOTE: THIS DOESN'T WORK WHEN YOU'RE ON THE VPN :(
(Well like, kind of. If you're on the Full Tunnel option of the VPN and this is running on the server then it **should** work.)
(But for some reason for local dev it HATED my VPN.)
(enjoy!)
 